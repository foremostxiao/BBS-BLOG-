1.作业题目：开发图书增删改查页面
2.作业需求:
		1.列出图书列表、出版社列表、作者列表
		2.点击作者，会列出其出版的图书列表
		3.点击出版社，会列出旗下图书列表
		4.可以创建、修改、删除 图书、作者、出版社

3.测试环境：win7系统，python3.7.0，工具:pycharm-Profession-2018.2.4
4.目录主要框架介绍
		bookms2
			-app01
				-static     # 放入bootstrap-3.3.7
				-models.py  # 用于建立表结构
				-urls.py    # 从路由
				-views.py	# 查、编辑、添加、删除的视图代码
			-bookms2
				-settings.py 
				-urls.py	# 主路由
			-templates
				-addbook.html
				-base.html
				-books.html
				-changebook.html
			db.sqlite3		# sqlite数据库
主要思路：
		1 在models.py建立表结构后进行数据库迁移
			python manage.py makemigrations
			python manage.py migrate
		2 在sqlite数据库表中Book表和Publish表添加部分数据
		3 进行查看、添加、编辑、删除html、views编写
		

	
	