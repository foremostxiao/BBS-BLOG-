from django.db import models

# Create your models here.
class Author(models.Model):
    nid=models.AutoField(primary_key=True)
    name=models.CharField(max_length=32)
    age=models.IntegerField()

class Publish(models.Model):
    nid=models.AutoField(primary_key=True)
    name=models.CharField(max_length=32)
    city=models.CharField(max_length=32)
    email=models.EmailField()


class Book(models.Model):
    nid=models.AutoField(primary_key=True)
    title=models.CharField(max_length=32)
    publishDate=models.DateField()
    price=models.DecimalField(max_digits=5,decimal_places=2)

    # 与publish建立一对多的关系，在健在多的一方(Book)
    # to=表名 to_field=字段
    publish=models.ForeignKey(to='Publish',to_field='nid',on_delete=models.CASCADE)

    # 与Author建立多对多的关系 可以建立在两个模型中的任意一个，自动创建第三张表
    authors=models.ManyToManyField(to='Author')