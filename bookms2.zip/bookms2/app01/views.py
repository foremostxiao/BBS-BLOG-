from django.shortcuts import render

# Create your views here.
from django.shortcuts import render,HttpResponse,redirect

# Create your views here.
from app01.models import Book,Publish,Author
def addbook(request):
    if request.method=='POST':
        # get--->name="price"
        title=request.POST.get('title')
        price=request.POST.get('price')
        pub_date=request.POST.get('pub_date')
        publish_id=request.POST.get('publish_id')
        # checkbox,select多选
        authors_id_list=request.POST.getlist('authors_id_list')
        if title == '' or price == '' or pub_date == '' or publish_id == '' or authors_id_list=='':
            return HttpResponse('<h3 style="color: #c7254e">所有选项不为空</h3>')
        # 添加数据
        book_obj=Book.objects.create(title=title,price=price,publishDate=pub_date,publish_id=publish_id)
        # 多对多
        # print(authors_id_list)#['2','3']
        book_obj.authors.add(*authors_id_list)

        return redirect('/app01/books/')

    publish_list=Publish.objects.all()
    author_list=Author.objects.all()
    return render(request,'addbook.html',{'publish_list':publish_list,'author_list':author_list})


def books(request):
    book_list=Book.objects.all()#[obj1,obj2]
    return render(request,'books.html',locals())


def delbook(request,id):
    Book.objects.filter(pk=id).delete()
    # 删除成功后做重定向

    # 方法一
    #return render(request,'books.html')

    # 方法二
    return redirect('/app01/books/')
def changebook(request,id):
    book_obj=Book.objects.filter(pk=id).first()
    if request.method == 'POST':
        title = request.POST.get('title')
        price = request.POST.get('price')
        pub_date = request.POST.get('pub_date')
        publish_id = request.POST.get('publish_id')
        authors_id_list=request.POST.getlist('authors_id_list')
        if title == '' or price == '' or pub_date == '' or publish_id == '' or authors_id_list=='':
            return HttpResponse('<h3 style="color: #c7254e">所有选项不为空</h3>')
        Book.objects.filter(pk=id).update(title=title, price=price, publishDate=pub_date, publish_id=publish_id)

        # 编辑时使用
        book_obj.authors.set(authors_id_list)
        return redirect('/app01/books/')


    publish_list = Publish.objects.all()
    author_list = Author.objects.all()
    return render(request,'changebook.html',{'book_obj':book_obj,'publish_list': publish_list, 'author_list': author_list})