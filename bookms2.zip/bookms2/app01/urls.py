from app01 import views
from django.urls import path,re_path
urlpatterns = [
    path('addbook/', views.addbook),
    path('books/', views.books),#查看
    re_path(r'books/(\d+)/delete', views.delbook),#删除 delbook(request,id)
    re_path(r'books/(\d+)/change', views.changebook),#编辑 changebook(request,id)

]